// const express = require("express");
// const app = express();
// require("dotenv").config();
// require("./conn/conn");
// const cors = require("cors");
// const UserAPI = require("./routes/user")
// const TaskAPI = require("./routes/task")
// app.use(cors());
// app.use(express.json())

// app.use("/api/v1", UserAPI)
// app.use("/api/v2", TaskAPI)
// //localhost:1000/api/v1/sign-in

// app.use("/", (req, res) =>{
//     res.send("Hello from backend side")
// });

// const PORT = 1000;

// app.listen(PORT, () => {
//     console.log("server started")
// })

const express = require("express");
const app = express();
require("dotenv").config();
require("./conn/conn"); // Assuming this connects to your database
const cors = require("cors");
const UserAPI = require("./routes/user");
const TaskAPI = require("./routes/task");

// Middleware
app.use(cors({
    origin: "http://localhost:3000", // Specify your frontend URL if you want to restrict access
    methods: "GET,POST,PUT,DELETE",
    credentials: true
}));
app.use(express.json());

// Routes
app.use("/api/v1", UserAPI);
app.use("/api/v2", TaskAPI);

// Default Route (for testing purposes)
app.use("/", (req, res) => {
    res.send("Hello from backend side");
});

// Error handling middleware (for catching unexpected errors)
app.use((err, req, res, next) => {
    console.error(err); // Log the error details
    const statusCode = err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(statusCode).json({ message });
});

// Start server
const PORT = process.env.PORT || 1000; // Allow setting the port from .env file
app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
});
