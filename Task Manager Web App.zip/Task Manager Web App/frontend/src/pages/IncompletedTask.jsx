import React from 'react'

const IncompletedTask = () => {
  return (
    <div>
      incompletedTasks
    </div>
  )
}

export default IncompletedTask
