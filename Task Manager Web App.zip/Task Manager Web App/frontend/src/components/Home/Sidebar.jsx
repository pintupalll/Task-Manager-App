import React from 'react'
import { GrNotes } from "react-icons/gr";
import { MdLabelImportantOutline } from "react-icons/md";
import { IoMdCheckboxOutline } from "react-icons/io";
import { TbNotesOff } from "react-icons/tb";
import { Link } from 'react-router-dom';


const Sidebar = () => {
    const data = [
        {
            title : "All Tasks",
            icon: <GrNotes />,
            link: "/",
        },
        {
            title : "Important Tasks",
            icon: <MdLabelImportantOutline />,
            link: "/importantTasks",
        },
        {
            title : "Completed Tasks",
            icon: <IoMdCheckboxOutline />,
            link: "/completedTasks",
        },
        {
            title : "Incompleted Tasks",
            icon : <TbNotesOff />,
            link: "/incompletedTasks",
        },
    ]
  return (
    <>
        <div>
            <h2 className='text-xl font-semibold'>Pintu pal</h2>
            <h4 className='mb-1 text-gray-400'>Pintu@gmail.com</h4>
            <hr />
        </div> 

        <div>
            {data.map((items, i) =>(
                <Link to={items.link} key="i" className='my-2 flex items-center hover:bg-gray-600 p-2 rouunded transition-all duration-300'>
                   {items.icon}&nbsp; {items.title}
                </Link>
            ))}
        </div>

        <div>
            <button className='bg-gray-600 w-full p-2 rounded'>Log Out</button>
        </div>
    </>
  )
}

export default Sidebar
